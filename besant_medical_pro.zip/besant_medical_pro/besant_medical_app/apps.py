from django.apps import AppConfig


class BesantMedicalAppConfig(AppConfig):
    name = 'besant_medical_app'
