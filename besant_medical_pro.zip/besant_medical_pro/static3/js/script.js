/**
 * Created by Soham on 07-11-2017.
 */

/**$(function () {
    $(".jumcust2").slideUp(5000);
});**/